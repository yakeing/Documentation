---
title: 关于
comments: false
---

## 作者

<img src="/images/avatar.jpg" title="Yakeing">

It 's my new attempt, so I hope all of you will support this blog.

一个普普通通的 **CodeR** 希望通过这个博客和大家一起学习更多知识。

因作者才疏学浅文章内容难免有错误之处，希望各位大神能够指正。

## 赞助

![Sponsor](https://oauth.applinzi.com/State/heart/Sponsor/EA4AAA.svg)

如果如果觉得文章的内容对你有所帮助就请给点赞助我们能对文章有持续更新能力!

 WeChat (微信赞助)

 ![WeChat](/images/WeChat.png)

 Alipay (支付宝赞助)

 ![Alipay](/images/Alipay.png)

 [Bitcoin](https://btc.com/1FYbZECgs3V3zRx6P7yAu2nCDXP2DHpwt8) (比特币赞助)

 1FYbZECgs3V3zRx6P7yAu2nCDXP2DHpwt8

### 关于图标

| icon | id | class name | glyph name |
| :----: | :----: | :---- | :---- |
| <i class="icon-paste vm"></i> | f0ea | icon-paste | clipboard, paste |
| <i class="icon-creative-commons vm"></i> | f25e | icon-creative-commons | creative-commons |
| <i class="icon-arrow-double-down vm"></i> | f103 | icon-arrow-double-down | angle-double-down |
| <i class="icon-arrdouble-left vm"></i> | f100 | icon-arrdouble-left | angle-double-left |
| <i class="icon-arrow-double-right vm"></i> | f101 | icon-arrow-double-right | angle-double-right |
| <i class="icon-arrow-double-up vm"></i> | f102 | icon-arrow-double-up | angle-double-up |
| <i class="icon-arrow-down vm"></i> | f107 | icon-arrow-down | angle-down |
| <i class="icon-arrow-left vm"></i> | f104 | icon-arrow-left | angle-left |
| <i class="icon-arrow-right vm"></i> | f105 | icon-arrow-right | angle-right |
| <i class="icon-arrow-up vm"></i> | f106 | icon-arrow-up | angle-up |
| <i class="icon-calendar vm"></i> | f0ce | icon-calendar | table |
| <i class="icon-camera vm"></i> | f03e | icon-camera | -o |
| <i class="icon-nav-up vm"></i> | f077 | icon-nav-up | chevron-up |
| <i class="icon-nav-right vm"></i> | f054 | icon-nav-right | chevron-right |
| <i class="icon-nav-down vm"></i> | f078 | icon-nav-down | chevron-down |
| <i class="icon-nav-left vm"></i> | f053 | icon-nav-left | chevron-left |
| <i class="icon-circle-info vm"></i> | f06a | icon-circle-info | exclamation-circle |
| <i class="icon-circle-more vm"></i> | e900 | icon-circle-more | circlemore |
| <i class="icon-comment vm"></i> | f27a | icon-comment | commenting |
| <i class="icon-document vm"></i> | f15c | icon-document | file-text |
| <i class="icon-documents vm"></i> | f009 | icon-documents | th-large |
| <i class="icon-home-stroke vm"></i> | f015 | icon-home-stroke | home |
| <i class="icon-heart vm"></i> | f004 | icon-heart | heart |
| <i class="icon-library vm"></i> | f00b | icon-library | th-list |
| <i class="icon-location vm"></i> | f041 | icon-location | map-marker |
| <i class="icon-lock vm"></i> | f023 | icon-lock | lock |
| <i class="icon-message-stroke vm"></i> | f0e0 | icon-message-stroke | envelope |
| <i class="icon-search-stroke vm"></i> | f002 | icon-search-stroke | search |
| <i class="icon-tag vm"></i> | f02b | icon-tag | tag |
| <i class="icon-time vm"></i> | f017 | icon-time | clock-o |
| <i class="icon-user-stroke vm"></i> | f2be | icon-user-stroke | user-circle-o |
| <i class="icon-video vm"></i> | f03d | icon-video | video-camera |
| <i class="icon-vote vm"></i> | f164 | icon-vote | thumbs-up |
| <i class="icon-write vm"></i> | f044 | icon-write | pencil-square-o |
| <i class="icon-link vm"></i> | f0c1 | icon-link | link |

### 关于作者

weibo: [yakeing](https://weibo.com/yakeing)

twitter: [yakeing](https://twitter.com/yakeing)
